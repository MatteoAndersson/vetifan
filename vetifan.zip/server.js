const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

app.use(express.static("./webbsidan"));


let boxPosition = 0;
let textValue;

io.on("connection", function(socket) {

    socket.emit("boxPosition", boxPosition);
    socket.emit("textValue", textValue)

    
    socket.on("updateBoxPosition", function(position) {
        
        boxPosition = position;
        io.emit("boxPosition", boxPosition);
    });
    socket.on("updateTextValue", function(value) {

        textValue = value;
        io.emit("textValue", textValue);
    });
});


http.listen(3000, () => {
    console.log("Servern körs, besök http://localhost:3000/index.html");
})